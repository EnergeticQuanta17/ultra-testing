# Coco > 2023-06-24 4:25pm
https://universe.roboflow.com/iotracx-internship/coco-luasp

Provided by a Roboflow user
License: CC BY 4.0

